--- 
title: FlatG is almost here!
slug: flatg-is-almost-here
date: 2013-07-10
tags: [testing, flatg]
categories: [hello, development]


# FlatG
![FlatG website](https://raw.github.com/goliatone/flatg-website/master/app/assets/images/flat-g-logo-128.png)

[![Build Status](https://secure.travis-ci.org/goliatone/FlatG.png)](http://travis-ci.org/goliatone/FlatG)

## Getting Started
Download the [production version][min] or the [development version][max].

[min]: https://raw.github.com/goliatone/flatg-website/master/dist/FlatG.min.js
[max]: https://raw.github.com/goliatone/flatg-website/master/dist/FlatG.js

## Development
`sudo npm install && bower install`

##Bower
>Bower is a package manager for the web. It offers a generic, unopinionated solution to the problem of front-end package management, while exposing the package dependency model via an API that can be consumed by a more opinionated build stack. There are no system wide dependencies, no dependencies are shared between different apps, and the dependency tree is flat.

To register FlatG in the [bower](http://bower.io/) [registry](http://sindresorhus.com/bower-components/):
`bower register FlatG git://github.com/goliatone/FlatG.git`


## Documentation
_(Coming soon)_

## Examples
_(Coming soon)_

## Release History
_(Nothing yet)_


```html
<div>This is something else</div>
```
